#!/usr/bin/env python
# coding: utf-8

# # PYTHON Worksheet 1 
# 
# #### 11. Write a python program to find the factorial of a number. 
# - __Iterative Function__

# In[12]:


def Factorial(n):
    return 1 if (n ==1 or n == 0) else n * Factorial(n - 1)
n = int(input("Enter a number : "))
print("The factorial of",n,"is: ",factorial(n))


# - __Recursive Function__ - calling a function within a function

# In[3]:


print("Factorial of a number is the product of all integers from 1 to the given number, Factorial of 0 is 1 and there is no factorial of negative numbers.")

def factorial(n):
    return 1 if (n ==1 or n == 0) else n * factorial(n - 1)
n = int(input("Please enter a positive integer:"))

if n<0:
    print('Factorial exists only for positive integers')
elif (n==0 & n ==1):
    print("factorial of ",num,"is 1")

else:
    print("The factorial of",n,"is: ",factorial(n))


# #### 12. Write a python program to find whether a number is prime or composite.

# In[4]:


print("===========Prime number is a number which is divisible by 1 and itself.============\n ==============A composite number has more than 2 divisors.=================")
num = int(input("\nEnter any number : "))
if num > 1:
    for i in range(2, num):
        if (num % i) == 0:
            print(num, "is NOT a prime number, it is a composite number.")
            break
    else:
        print(num, "is a PRIME number.")
elif num == 0 or 1:
    print(num, "is a neither prime NOR composite number.")


# #### 13. Write a python program to check whether a given string is palindrome or not. 

# In[45]:


print('-'*20,"A Palindrome is a word,sequence or number which reads the same backwards as forward",'-'*20,sep='')

def isPalindrome(s):
    return s == s[::-1]
 
s = str(input("\nEnter any word : "))
ans = isPalindrome(s)
 
if ans:
    print(s,"is indeed a Palindrome!")
else:
    print("The entered word is not a Palindrome")


# #### 14. Write a Python program to get the third side of right-angled triangle from two given sides. 

# In[43]:


print("If two sides of a right-angled triangle is known then the third side can be found using Pythagoras Theorem.\n","-"*246, "It states that Square of hypotenuse is equal to the sum of squares of other two sides of a right-angled triangle.\n","\n c = numpy.sqrt(numpy.square(a) + numpy.square(b))")


# In[46]:


from math import sqrt
print("Input lengths of two sides of a triangle sides:")
a = float(input("a: "))
b = float(input("b: "))

c = sqrt(a**2 + b**2)
print("The length of the hypotenuse(third side) is", c )


# In[42]:


def Hypotenuse(side1, side2):
 
    h = (((side1 **2) + (side2 **2))**(1/2))
    return h
 
# Driver code
side1 = float(input("a: "))
side2 = float(input("a: "))
 
print(Hypotenuse(side1, side2))


# #### 15. Write a python program to print the frequency of each of the characters present in a given string.

# In[36]:


def charFrequency(userInput):
    userInput = userInput.lower()
    dict = {}
    for char in userInput:
        keys = dict.keys()
        if char in keys:
            dict[char] += 1
        else:
            dict[char] = 1
    return dict

if __name__ == '__main__':
    userInput = str(input('Enter a string: '))
    print(charFrequency(userInput))


# In[47]:


string=input("Enter the string !!")
newstr=list(string)
newlist=[]

for j in newstr:
     if j not in newlist:
        newlist.append(j)
        count=0
        
        for i in range(len(newstr)):
            if j==newstr[i]:
                count+=1

        print("{},{}".format(j,count))


# In[ ]:




